#pragma once
#include "auton.hpp"
#include "category.hpp"
#include "selector.hpp"